package com.company;

public class Info {
    public String name;
    public String username;
    public int pass;

}
